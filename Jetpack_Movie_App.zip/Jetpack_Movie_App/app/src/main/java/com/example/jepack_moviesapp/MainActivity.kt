package com.example.jepack_moviesapp


import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.jepack_moviesapp.model.Movie

import com.example.jepack_moviesapp.viemodel.MovieViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MovieApp()
        }
    }
}

@Composable
fun MovieApp() {
    val viewModel: MovieViewModel = viewModel()
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = "movie_list") {
        composable("movie_list") {
            MovieList(navController, viewModel)
        }
        composable("movie_detail/{movieTitle}/{moviePoster}/{movieRating}/{movieOverview}") { backStackEntry ->
            val movie = Movie(
                id = 0, // Fix: Add missing id
                title = backStackEntry.arguments?.getString("movieTitle") ?: "",
                poster_path = backStackEntry.arguments?.getString("moviePoster") ?: "",
                vote_average = backStackEntry.arguments?.getString("movieRating")?.toDoubleOrNull() ?: 0.0,
                overview = backStackEntry.arguments?.getString("movieOverview") ?: ""
            )
            MovieDetail(movie)
        }
    }
}
