package com.example.jepack_moviesapp
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.rememberImagePainter
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.jepack_moviesapp.model.Movie
import com.example.jepack_moviesapp.viemodel.MovieViewModel
import android.net.Uri



@Composable
fun MovieList(
    navController: NavController,
    viewModel: MovieViewModel = viewModel()
) {
    val movies by viewModel.movies.collectAsState()

    Column {
        var searchQuery by remember { mutableStateOf("") }

        // Search Bar
        TextField(
            value = searchQuery,
            onValueChange = { query ->
                searchQuery = query
                viewModel.searchMovies(query)
            },
            label = { Text("Search Movies") },
            modifier = Modifier.fillMaxWidth()
        )

        // Movie List
        LazyColumn {
            items(movies) { movie ->
                MovieItem(movie, navController)
            }
        }
    }
}

@Composable
fun MovieItem(movie: Movie, navController: NavController) {
    Card(
        shape = RoundedCornerShape(10.dp),
        elevation = 4.dp,
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
            .clickable {
                navController.navigate(
                    "movie_detail/${Uri.encode(movie.title)}/${Uri.encode(movie.poster_path)}/${movie.vote_average}/${Uri.encode(movie.overview)}"
                )
            }
    ) {
        Row(Modifier.padding(8.dp)) {
            Image(
                painter = rememberImagePainter("https://image.tmdb.org/t/p/w500${movie.poster_path}"),
                contentDescription = null,
                modifier = Modifier.size(100.dp),
                contentScale = ContentScale.Crop
            )
            Spacer(Modifier.width(8.dp))
            Column {
                Text(movie.title, fontWeight = FontWeight.Bold)
                Text("Rating: ${movie.vote_average}", color = Color.Gray)
            }
        }
    }
}
