package com.example.jepack_moviesapp

import com.example.jepack_moviesapp.model.MovieResponse


class MovieRepository(private val apiService: MovieApiService) {
    suspend fun getTrendingMovies(apiKey: String): MovieResponse {
        return apiService.getTrendingMovies(apiKey)
    }

    suspend fun searchMovies(apiKey: String, query: String): MovieResponse {
        return apiService.searchMovies(apiKey, query)
    }
}