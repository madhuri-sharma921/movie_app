package com.example.jepack_moviesapp.model


data class MovieResponse(
    val results: List<Movie>
)
