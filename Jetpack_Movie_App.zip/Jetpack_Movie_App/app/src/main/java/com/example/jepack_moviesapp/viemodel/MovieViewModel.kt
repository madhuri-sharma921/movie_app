package com.example.jepack_moviesapp.viemodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.jepack_moviesapp.MovieRepository
import com.example.jepack_moviesapp.RetrofitClient
import com.example.jepack_moviesapp.model.Movie
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class MovieViewModel : ViewModel() {
    private val repository = MovieRepository(RetrofitClient.apiService)
    private val _movies = MutableStateFlow<List<Movie>>(emptyList())
    val movies: StateFlow<List<Movie>> = _movies

    private val apiKey = "02d28108a4204e108802d75a3dfbdc9c"

    init {
        getTrendingMovies()
    }

    fun getTrendingMovies() {
        viewModelScope.launch {
            try {
                val response = repository.getTrendingMovies(apiKey)
                _movies.value = response.results
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun searchMovies(query: String) {
        viewModelScope.launch {
            if (query.isEmpty()) {
                getTrendingMovies() // Reset to trending movies instantly when search is cleared
                return@launch
            }

            try {
                val response = repository.searchMovies(apiKey, query)
                _movies.value = response.results
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

}
